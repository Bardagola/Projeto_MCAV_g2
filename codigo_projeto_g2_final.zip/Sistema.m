clear all
close all
clc

%Parametros de modelação

g_mars = 3.72;
Cd = 2.05;
ro_mars=0.02;

xr = 2.7;
yr = 2.9;
zr = 2.2;
mr = 1025;

jr = [(1/12)*mr*(yr^2+zr^2) 0 0
      0 (1/12)*mr*(xr^2+zr^2) 0
      0 0 (1/12)*mr*(yr^2+xr^2)];

xl=3.4;
yl=3.4;
zl = 3;
ml = 2064;

jl = [(1/12)*ml*(yl^2+zl^2) 0 0
      0 (1/12)*ml*(xl^2+zl^2) 0
      0 0 (1/12)*ml*(yl^2+xl^2)];

%Parametros de simulação

zI=[0;0;1];
Dt=0.01;
t=0:Dt:120;
Nsim=length(t);
x=zeros(12,Nsim);
x(:,1) = [0;0;-2100;zeros(2,1);83.3;zeros(6,1)];
u = zeros(4,Nsim);

wx = 0;  %Condições do equilíbrio
wy = 0;
wz = 0;
omega_eq = [wx;wy;wz]; 
C=[eye(3) zeros(3) zeros(3) zeros(3)
   zeros(3) eye(3) zeros(3) zeros(3)];

W1 = diag([0.01;0.01;100;0.01;0.01;1000;0.001*ones(6,1)]);
W2 = eye(4);
D11 = zeros(16,12);
D12 = [zeros(12,4);W2];
D22 = zeros(12,4);
D21 = eye(12);
D0 = [D11 D12;D21 D22];
C1 = [W1;zeros(4,12)];
C2 = -eye(12);
C0 = [C1;C2];
nmeas = 12;
ncont = 4;
B1 = zeros(12);

% Modo 1

v_eq1 = [0;0;83.3];
m = mr+ml;
fa_dot1=Cd*ro_mars*xr*yr*v_eq1(3)/m;
phi1 = 0;
theta1 = 0;
psi1 = 0;
lambda_eq1 = deg2rad([phi1;theta1;psi1]);

cmz = (zr*mr+zl*ml)/m;        
z = cmz-2.2;        
J = [jl(1,1)+ml*(1.5-z)^2+jr(1,1)+mr*(cmz-1.1)^2 0 0
     0 jl(2,2)+ml*(1.5-z)^2+jr(2,2)+mr*(cmz-1.1)^2 0
     0 0 jl(3,3)+jr(3,3)];

f1 = [0;sin(deg2rad(180+20));cos(deg2rad(180+20))];
p1 = [1.7;1.7;z];
n1 = cross(p1,f1);
f2 = [0;sin(deg2rad(180+20));cos(deg2rad(180+20))];
p2 = [-1.7;1.7;z];
n2 = cross(p2,f2);        
f3 = [0;sin(deg2rad(180-20));cos(deg2rad(180-20))];
p3 = [-1.7;-1.7;z];
n3 = cross(p3,f3);        
f4 = [0;sin(deg2rad(180-20));cos(deg2rad(180-20))];
p4 = [1.7;-1.7;z];
n4 = cross(p4,f4);

Bm1 = [zeros(3,4)
   1/m*f1 1/m*f2 1/m*f3 1/m*f4
   zeros(3,4)
   J^-1*n1 J^-1*n2 J^-1*n3 J^-1*n4];

a1 = [cos(phi1)*tan(theta1)*(wy+wz), -wy*sin(phi1)-wz*cos(phi1), (wy*cos(phi1)-wz*sin(phi1))/cos(theta1)
    (sin(phi1)/(cos(theta1))^2)*(wy+wz), 0, (wy*sin(phi1)*sin(theta1)+wz*cos(phi1)*sin(theta1))/(cos(theta1)^2)
    0 0 0];

A1 = [zeros(3) Euler2R(lambda_eq1) skew(v_eq1) zeros(3)
      zeros(3) skew(-omega_eq)-[zeros(2,3);0 0 -fa_dot1] skew([0;0;-g_mars]) skew(v_eq1)
      zeros(3) zeros(3) a1 Euler2Q(lambda_eq1)
      zeros(3) zeros(3) zeros(3) zeros(3)];

B21 = Bm1;
B01 = [B1 B21];
P1 = ss(A1,B01,C0,D0);
r1 = [0*(t>=0);0*(t>=0);x(3,1)+v_eq1(3)*t.*(t>=0);
v_eq1*(t>=0);lambda_eq1*(t>=0);omega_eq*(t>=0)];
[K1,CL1,gamma1] = hinfsyn(P1,nmeas,ncont);

% Modo 2

v_eq2 = [0;0;41.7];
fa_dot2=Cd*ro_mars*xr*yr*v_eq2(3)/m;

A2 = [zeros(3) Euler2R(lambda_eq1) skew(v_eq2) zeros(3)
      zeros(3) skew(-omega_eq)-[zeros(2,3);0 0 -fa_dot2] skew([0;0;-g_mars]) skew(v_eq2)
      zeros(3) zeros(3) a1 Euler2Q(lambda_eq1)
      zeros(3) zeros(3) zeros(3) zeros(3)];

B02 = [B1 B21];
P2 = ss(A2,B02,C0,D0);
[K2,CL2,gamma2] = hinfsyn(P2,nmeas,ncont);

% Modo 3

v_eq3 = [0;0;0];
fa_dot3 = Cd*ro_mars*xr*yr*v_eq3(3)/m;

A3 = [zeros(3) Euler2R(lambda_eq1) skew(v_eq3) zeros(3)
      zeros(3) skew(-omega_eq)-[zeros(2,3);0 0 -fa_dot3] skew([0;0;-g_mars]) skew(v_eq3)
      zeros(3) zeros(3) a1 Euler2Q(lambda_eq1)
      zeros(3) zeros(3) zeros(3) zeros(3)];

B03 = [B1 B21];
P3 = ss(A3,B03,C0,D0);
[K3,CL3,gamma3] = hinfsyn(P3,nmeas,ncont);

% Modo 4

cmz4 = zl/2;
z4 = cmz4;

f14 = [0;sin(deg2rad(180+20));cos(deg2rad(180+20))];
p14 = [1.7;1.7;z4];
n14 = cross(p14,f14);
f24 = [0;sin(deg2rad(180+20));cos(deg2rad(180+20))];
p24 = [-1.7;1.7;z4];
n24 = cross(p24,f24);        
f34 = [0;sin(deg2rad(180-20));cos(deg2rad(180-20))];
p34 = [-1.7;-1.7;z4];
n34 = cross(p34,f34);        
f44 = [0;sin(deg2rad(180-20));cos(deg2rad(180-20))];
p44 = [1.7;-1.7;z4];
n44 = cross(p44,f44);

phi4 = 5;
theta4 = 0;
psi4 = 0;
lambda_eq4 = deg2rad([phi4;theta4;psi4]);
v_eq4 = [0;10;0];
fa_dot4 = Cd*ro_mars*xl*yl*v_eq4(3)/ml;

Bm4 = [zeros(3,4)
        1/ml*f14 1/ml*f24 1/ml*f34 1/ml*f44
        zeros(3,4)
        jl^-1*n14 jl^-1*n24 jl^-1*n34 jl^-1*n44];

a4 = [cos(phi4)*tan(theta4)*(wy+wz), -wy*sin(phi4)-wz*cos(phi4), (wy*cos(phi4)-wz*sin(phi4))/cos(theta4)
    (sin(phi4)/(cos(theta4))^2)*(wy+wz), 0, (wy*sin(phi4)*sin(theta4)+wz*cos(phi4)*sin(theta4))/(cos(theta4)^2)
    0 0 0];

v4 = [0;v_eq4(2)*sin(deg2rad(phi4));v_eq4(2)*cos(deg2rad(phi4))];

A4 = [zeros(3) Euler2R(lambda_eq4) skew(v4) zeros(3)
      zeros(3) skew(-omega_eq)-[zeros(2,3);0 0 -fa_dot4] skew([0;0;-g_mars]) skew(v_eq4)
      zeros(3) zeros(3) a4 Euler2Q(lambda_eq4)
      zeros(3) zeros(3) zeros(3) zeros(3)];

B04 = [B1 Bm4];
P4 = ss(A4,B04,C0,D0);
[K4,CL4,gamma4] = hinfsyn(P4,nmeas,ncont);

%% Simulação

ran1 = false;
ran2 = false;
ran3 = false;

for k = 1:Nsim
    
    h = x(3,k);

    if h < -1000

        r = r1;
        K = K1;
    
    elseif (-1000 <= h) && (h < -500)
        
        if ran1 == false

            r2 = [0*(t>=0);0*(t>=0);(h-v_eq2(3)*t(k))+v_eq2(3)*t.*(t>=0);
                 v_eq2*(t>=0);lambda_eq1*(t>=0);omega_eq*(t>=0)];
            ran1 = true;
        
        end

        r = r2;
        K = K2;
    
    elseif (h >= -100) && (h < 0)

        if ran2 == false

            r3 = [0*(t>=0);0*(t>=0);(-100-v_eq3(3)*t(k))+v_eq3(3)*t.*(t>=0);
                 v_eq3*(t>=0);lambda_eq1*(t>=0);omega_eq*(t>=0)];
            ran2 = true;
            cont = k+1000;
        
        end

        % if k < cont

            r = r3;
            K = K3;

        % else

            % if ran3 == false
            % 
            %     r4 = [0*(t>=0);(x(3,cont)-v_eq4(2)*t(cont))+v_eq4(2)*t.*(t>=0);x(3)*(t>=0);
            %       v_eq4*(t>=0);lambda_eq4*(t>=0);omega_eq*(t>=0)];
            %     ran3 = true;
            % 
            % end

            % r = r4;
            % K = K4;

        % end

    elseif h >= 0

        break

    end
    
    p = x(1:3,k);
    v = x(4:6,k);
    lambda = x(7:9,k);
    omega = x(10:12,k);
    R = Euler2R(lambda);
    Q = Euler2Q(lambda);

    q = r(:,k)-x(:,k);
    u(:,k) = -K.C*q;

    T = [f1 f2 f3 f4]*u(:,k);
    np=[n1 n2 n3 n4]*u(:,k);
    
    p_dot = R*v;
    lambda_dot = Q*omega;
    v_dot = -skew(omega)*v+(g_mars*R.'*zI)-(0.5*Cd*ro_mars*xr*yr*zI*v(3)^2/m)+(T/m);
    omega_dot = (-J^-1*skew(omega)*J*omega)+(J^-1*np);
    x_dot = [p_dot;v_dot;lambda_dot;omega_dot];
    xp = x(:,k) + Dt*x_dot;

    if k < Nsim
        x(:,k+1) = xp;
    end
    
end

y = C*x(:,1:k);
figure(1);
plot(t(1,1:k),y(1,:),'k',t(1,1:k),y(2,:),'r',t(1,1:k),y(3,:),'g',t(1,1:k),y(4,:),'y',t(1,1:k),y(5,:),'b',t(1,1:k),y(6,:),'c');
legend('p_x','p_y','p_z','v_x','v_y','v_z');
% plot(t,r(1,:),'k',t,r(2,:),'g',t,r(3,:),'r',t,r(6,:),'b');
grid on;
figure(2)
plot(t(1,1:k),r1(3,1:k),'k',t(1,1:k),r2(3,1:k),'r',t(1,1:k),r3(3,1:k),'g',t(1,1:k),y(6,1:k),'b');
grid on;
figure(3);
plot(t(1,1:k),u(:,1:k));
grid on;



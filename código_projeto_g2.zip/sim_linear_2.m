clear all

##Parametros

g_mars=3.72
Cd=2.05
ro_mars=0.02

xr=2.7
yr=2.9
zr=2.2
mr=1025

jr = [(1/12)*mr*(yr^2+zr^2) 0 0
0 (1/12)*mr*(xr^2+zr^2) 0
0 0 (1/12)*mr*(yr^2+xr^2)]

xl=3.4
yl=3.4
zl=3
ml=2064

jl = [(1/12)*ml*(yl^2+zl^2) 0 0
0 (1/12)*ml*(xl^2+zl^2) 0
0 0 (1/12)*ml*(yl^2+xl^2)]

m=mr+ml

cmz=(zr*mr+zl*ml)/m

z = cmz-2.2

J = [jl(1,1)+ml*(1.5-z)^2+jr(1,1)+mr*(cmz-1.1)^2 0 0
     0 jl(2,2)+ml*(1.5-z)^2+jr(2,2)+mr*(cmz-1.1)^2 0
     0 0 jl(3,3)+jr(3,3)]

##Forças de propulsão e momentos associados(T=1)

f1=[0;sin(deg2rad(180+20));cos(deg2rad(180+20))]
p1=[1.7;1.7;0.5345]
n1=cross(p1,f1)

f2=[0;sin(deg2rad(180+20));cos(deg2rad(180+20))]
p2=[-1.7;1.7;0.5345]
n2=cross(p2,f2)

f3=[0;sin(deg2rad(180-20));cos(deg2rad(180-20))]
p3=[-1.7;-1.7;0.5345]
n3=cross(p3,f3)

f4=[0;sin(deg2rad(180-20));cos(deg2rad(180-20))]
p4=[1.7;-1.7;0.5345]
n4=cross(p4,f4)

#linearização

zI=[0;0;1];
Dt=0.01;
t=0:Dt:60;
Nsim=length(t);
x0=[0;0;-2100;zeros(9,1)];
x=zeros(12,Nsim);
y=zeros(4,Nsim);
u=ones(length(t),1)*[0.1*m*g_mars,0.1*m*g_mars,0.1*m*g_mars,0.1*m*g_mars];

omega_eq=zeros(3,1); #Condições do equilíbrio
v_eq=[0;0;41.7];
lambda_eq=zeros(3,1);
fa_dot=Cd*ro_mars*xr*yr*v_eq(3)/m;

C=[eye(3) zeros(3) zeros(3) zeros(3)
   zeros(1,3) zeros(1,3) zI.' zeros(1,3)];

B=[zeros(3,1) zeros(3)
   1/m*zI zeros(3)
   zeros(3,1) zeros(3)
   zeros(3,1) J^-1];

A=[zeros(3) Euler2R(lambda_eq) zeros(3) zeros(3)
    zeros(3) skew(-omega_eq)-[zeros(2,3);0 0 -fa_dot] skew([0;0;-g_mars]) skew(v_eq)
    zeros(3) zeros(3) zeros(3) Euler2Q(lambda_eq)
    zeros(3) zeros(3) zeros(3) zeros(3)];

D=zeros(4);

sys = ss(A,B,C,D);

y=lsim(sys,u,t,x0);

figure(1);
plot(t,u);
figure(2)
plot(t,y(:,1),'b',t,y(:,2),'r',t,y(:,3),'g',t,y(:,4),'y')

#Controlabilidade, observabilidade e estabilidade

[Vj,Jor] = jordan(sym(A)),
[V,DL,W] = eig(A);
mode_obs = C*V
mode_ctrl = W'*B
